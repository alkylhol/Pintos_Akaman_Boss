
#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "threads/synch.h"
void syscall_init (void);
//struct lock* get_file_lock(void);
#endif /* userprog/syscall.h */
